﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace entity
{
    
    public class ServiceOrenda
    {
        Orenda1Entities service = new Orenda1Entities();
        public void Registration(Client client)
        {
            service.Clients.Add(client);
            service.SaveChanges();
        }




        public bool Login(string login,string password)
        {
            var log = service.Clients.FirstOrDefault(p => p.Login == login && p.Password == password);

            if(log != null)
            {
                return true;
            }
            return false;

        }


        public IQueryable<Department> getTableDep()
        {
            return service.Departments;
        }


        public IQueryable<Client> getTableCli()
        {
            return service.Clients;
        }






        public string ComputeSha256Hash(string rawData)
        {

            using (SHA256 sha256Hash = SHA256.Create())
            {

                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));


                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }

        }


    }
}
