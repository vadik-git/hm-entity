﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace entity
{
    /// <summary>
    /// Логика взаимодействия для BaseOrend.xaml
    /// </summary>
    public partial class BaseOrend : Page
    {
        ServiceOrenda service = null;

        Client[] arrCl = new Client[10];

        public BaseOrend()
        {
            InitializeComponent();


            service = new ServiceOrenda();

           dataGrid.ItemsSource = service.getTableDep().ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dataGrid.ItemsSource = service.getTableCli().ToList();

               
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {

                this.NavigationService.Navigate(new PageLogin());       

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
